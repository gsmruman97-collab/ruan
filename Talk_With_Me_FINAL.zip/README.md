# Talk With Me 🌍

Global private chat starter using Node.js, Express, SQLite and Socket.IO.

## Local
Node.js 20+, then `npm install`, set `SESSION_SECRET`, and run `npm start`.

## Render
Create a Node Web Service from this repository. Build: `npm install`. Start: `npm start`.
Add `SESSION_SECRET` and set `NODE_ENV=production`.

For a serious public launch, migrate SQLite and the default session store to managed persistent services, and add email verification, password reset, moderation/reporting, anti-spam, backups, monitoring, privacy/terms and age/safety controls.
